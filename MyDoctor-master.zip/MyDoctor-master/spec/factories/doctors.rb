FactoryGirl.define do
  factory :doctor do
    name "Test Doctor"
    email "doctor1@d1.com"
    password "12345678"
  end

end
