FactoryGirl.define do
  factory :patient do
    
  end

end
