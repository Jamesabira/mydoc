FactoryGirl.define do
  factory :appointment do
    date "2016-04-27"
time "2016-04-27 15:27:41"
Patient nil
Doctor nil
  end

end
