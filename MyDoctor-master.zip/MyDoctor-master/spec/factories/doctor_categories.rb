FactoryGirl.define do
  factory :doctor_category do
    name "MyString"
  end

end
