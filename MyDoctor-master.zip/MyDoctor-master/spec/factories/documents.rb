FactoryGirl.define do
  factory :document do
    
  end

end
