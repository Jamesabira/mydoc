module ApplicationHelper

 def ts_week_days
 	TimeSlot::WEEK_DAYS
 end

end
