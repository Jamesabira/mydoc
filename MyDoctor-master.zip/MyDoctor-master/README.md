 [![Code Climate](https://codeclimate.com/github/MarlabsKochi/MyDoctor.png)](https://codeclimate.com/github/MarlabsKochi/MyDoctor)
 [![Build Status](https://travis-ci.org/MarlabsKochi/MyDoctor.png)](https://travis-ci.org/MarlabsKochi/MyDoctor)
 [![Test Coverage](https://codeclimate.com/github/MarlabsKochi/MyDoctor/badges/coverage.svg)](https://codeclimate.com/github/MarlabsKochi/MyDoctor/coverage)
